from scipy.special import hankel1, jv, yv
import numpy as np

a = hankel1(16, 3)
b = jv(np.array([16, 12]), np.array([3, 3])) + yv(np.array([16, 12]), np.array([3, 3])) * 1j

print(a)
print(b)