from dataclasses import dataclass
from abc import ABC, abstractmethod

import numpy as np
from numpy.typing import NDArray

FloatArray = NDArray[np.float64]


class ParamCurve(ABC):
    """
    Parametrized curve in the plane: (x(t), y(t)), typically with t in [-1, 1].
    Implementations must be vectorized (accept numpy arrays).
    """

    @abstractmethod
    def x(self, t: FloatArray) -> FloatArray: ...

    @abstractmethod
    def y(self, t: FloatArray) -> FloatArray: ...

    @abstractmethod
    def x_der(self, t: FloatArray) -> FloatArray: ...

    @abstractmethod
    def y_der(self, t: FloatArray) -> FloatArray: ...

    def R(self, t: FloatArray, t0: FloatArray) -> FloatArray:
        """
        Pairwise distance R(t, t0) = sqrt( (x(t)-x(t0))^2 + (y(t)-y(t0))^2 )

        Supports broadcasting: t and t0 can be (n,1) and (1,m).
        """
        xt = self.x(t)
        yt = self.y(t)
        xt0 = self.x(t0)
        yt0 = self.y(t0)
        return np.sqrt((xt - xt0) ** 2 + (yt - yt0) ** 2)

    def R_der(self, t: FloatArray, x_o: FloatArray) -> FloatArray:
        """Mathematica provided"""
        xt = self.x(t)
        yt = self.y(t)
        result = ((x_o[0] - xt) * self.x_der(t) + (x_o[1] - yt) * self.y_der(t)) / np.sqrt(
            (x_o[0] - xt) ** 2 + (x_o[1] - yt) ** 2
        )
        return result


@dataclass(frozen=True)
class LineSegment(ParamCurve):
    """
    Straight line from P0=(x0,y0) to P1=(x1,y1) with t in [-1,1].

    Mapping: s=(t+1)/2 in [0,1], then P(t)=P0 + s*(P1-P0).
    """

    x0: float
    y0: float
    x1: float
    y1: float

    def x(self, t: FloatArray) -> FloatArray:
        s = (t + 1.0) / 2
        return self.x0 + s * (self.x1 - self.x0)

    def y(self, t: FloatArray) -> FloatArray:
        s = (t + 1.0) / 2
        return self.y0 + s * (self.y1 - self.y0)

    def x_der(self, t: FloatArray) -> FloatArray:
        return self.x1 / 2

    def y_der(self, t: FloatArray) -> FloatArray:
        return self.y1 / 2
